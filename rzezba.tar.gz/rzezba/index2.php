<?php
//echo "ciastko: " . $_COOKIE["ciacho"] . ".<br>";

if (isset($_COOKIE["ciacho"])) {
echo '

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Ankieta - rzeźba</title>
  <link rel="stylesheet" href="css/style.css">
  <link href="lb/dist/css/lightbox.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.sstatic.net/clc/styles/clc.min.css?v=8a0a093a431f" type="text/css">
          <link href="lb/dist/css/lightbox.css" rel="stylesheet">
          <script src="//code.jquery.com/jquery-1.11.2.min.js"></script>  
  

</head>
<script src="lb/src/js/lightbox.js"></script>


<script src="//code.jquery.com/jquery-1.11.2.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<body>

  <div class="container">
  
  <h2>Ankieta dotycząca projektu i lokalizacji rzeźby</h2>
  Oferty, które wpłynęły do Zarządu Dróg Miejskich w Puławach w odpowiedzi na zapytanie ofertowe dotyczące realizacji zadania ławeczki z postacią księżnej Izabeli Czartoryskiej różniły się ilością załączników graficznych, dlatego niektóre propozycje zawierają więcej niż jedną wizualizację.
  <form action="tel.php" name="ankieta">
Proszę wybrać jedną propozycję:<br><fieldset>
    <input type="radio" name="pradio1" id="pradio1" value="p1">Propozycja 1 - Rzeźba z atestowanego Brąz BK 331, spawana w osłonie gazów szlachetnych, cyzelowana i patynowana<br>
    											 <a href="img/1_1.jpg" data-lightbox="image-1" ><span class="ui-icon-image">Zdjęcie 1</span></a>
    											 <a href="img/1_2.jpg" data-lightbox="image-1" ><span class="ui-icon-image">Zdjęcie 2</span></a>
    											 <a href="img/1_3.jpg" data-lightbox="image-1" ><span class="ui-icon-image">Zdjęcie 3</span></a>
    											 <a href="img/1_4.jpg" data-lightbox="image-1" ><span class="ui-icon-image">Zdjęcie 4</span></a>
    <hr>

    <input type="radio" name="pradio1" id="pradio2" value="p2">Propozycja 2 - Rzeźba z Brązu<br>
    											<a href="img/2_1.jpg" data-lightbox="image-2" ><span class="ui-icon-image">Zdjęcie 1</span></a>
    											<a href="img/2_2.jpg" data-lightbox="image-2" ><span class="ui-icon-image">Zdjęcie 2</span></a>
    <hr>
    
    <input type="radio" name="pradio1" id="pradio3" value="p3">Propozycja 3 - Rzeźba z Brązu, patynowana<br>
    											<a href="img/3.jpg" data-lightbox="image-3" ><span class="ui-icon-image">Zdjęcie 1</span></a></label>
    <hr>
    
   <input type="radio" name="pradio1" id="pradio4" value="p4">Propozycja 4 - Rzeźba z Brązu<br>
   											<a href="img/4.jpg" data-lightbox="image-4" ><span class="ui-icon-image">Zdjęcie 1</span></a>
    <hr>
    
    <input type="radio" name="pradio1" id="pradio5" value="p5">Propozycja 5 - Rzeźba z Brązu, cyzelowane, patynowanie<br>
    											<a href="img/5_1.jpg" data-lightbox="image-5" ><span class="ui-icon-image">Zdjęcie 1</span></a>
    											<a href="img/5_2.jpg" data-lightbox="image-5" ><span class="ui-icon-image">Zdjęcie 2</span></a>
    <hr>
    
    <input type="radio" name="pradio1" id="pradio6" value="p6">Propozycja 6 - Brąz krzemowy BK331, patynowany<br>
    											<a href="img/6_1.jpg" data-lightbox="image-6" ><span class="ui-icon-image">Zdjęcie 1</span></a>
    											<a href="img/6_2.jpg" data-lightbox="image-6" ><span class="ui-icon-image">Zdjęcie 2</span></a>
    											<a href="img/6_3.jpg" data-lightbox="image-6" ><span class="ui-icon-image">Zdjęcie 3</span></a>
    <hr>
    
    <input type="radio" name="pradio1" id="pradio7" value="p7">Propozycja 7 - Rzeźba z Brązu, patynowana<br>
    											<a href="img/7.jpg" data-lightbox="image-7" ><span class="ui-icon-image">Zdjęcie 1</span></a>
    <hr>
    
</fieldset><br>Proszę wybrać jedną lokalizację:<a href="img/mapa.png" data-lightbox="image-8"><span class="ui-icon-image">(mapa lokalizacji)</span></a><br>
<fieldset>
    <input type="radio" name="lradio2" id="lradio1" value="l1">Lokalizacja 1 - <a href="img/l1.jpg" data-lightbox="image-9" ><span class="ui-icon-image">Zdjęcie</span></a>
    <hr>

    <input type="radio" name="lradio2" id="lradio2" value="l2">Lokalizacja 2 - <a href="img/l2.jpg" data-lightbox="image-9" ><span class="ui-icon-image">Zdjęcie</span></a>
    <hr>
    
    <input type="radio" name="lradio2" id="lradio3" value="l3">Lokalizacja 3 - <a href="img/l3.jpg" data-lightbox="image-9" ><span class="ui-icon-image">Zdjęcie</span></a>
    <hr>
</fieldset><br>
<fieldset> 
    <label for="tel">Proszę o podanie numeru telefonu</label>
    <input type="text" name="tel" id="tel" placeholder="np. 123123123 ">
</fieldset>    
    <button type="submit">Wyślij (bezpłatny) SMS na mój numer i przejdź do autoryzacji. </button>
    <div class="errorTxt"></div>
  </form>

  
</div>
  <script src="https://cdn.jsdelivr.net/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>

  

    <script  src="js/index.js"></script>




</body>

</html>';}

else {
	echo '
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Ankieta - rzeźba</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="container">
  <form action="../rzezba">
  Nie zaakceptowałeś regulaminu!!!   
    <button type="submit">Wróć do regulaminu</button>
  </form>

  
</div>
  <script src="https://cdn.jsdelivr.net/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>

  

    <script  src="js/index.js"></script>




</body>

</html>	
	
	
	';
}

?>
