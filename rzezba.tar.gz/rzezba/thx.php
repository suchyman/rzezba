<?php

//echo "ciastko: " . $_COOKIE["ciacho"] . ".<br>";

$ok = $_GET['kod'];
//echo $ok . " <br>";
$servername = "localhost";
$username = "root";
$password = "xxx";
$dbname = "ankieta";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT kod FROM odp WHERE kod = $ok";
$result = $conn->query($sql);

if (($result->num_rows > 0) AND (isset($_COOKIE["ciacho"]))) {
    // output data of each row
    //echo 'Jest taki kod i poszlo ok';
	
	$ciastko = $_COOKIE["ciacho"];
	$sql = "UPDATE odp SET ok='1', wkod=$ok  WHERE ciastko=$ciastko";

if (mysqli_query($conn, $sql)) {
   // echo "Record updated successfully";
} else {
   // echo "Error updating record: " . mysqli_error($conn);
}

setcookie("ciacho", "", time()-3600);
	unset($_COOKIE['ciacho']);
echo '

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Ankieta - rzeźba</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="container">
  <h2>Dziękujemy</h2>
  <form action="pulawy.eu">
  Dziękujemy za wyrażenie Twojej opini.    
    <button type="submit">Powrót na pulawy.eu</button>
  </form>

  
</div>
  <script src="https://cdn.jsdelivr.net/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>

  

    <script  src="js/index.js"></script>




</body>

</html>';}

else {
	setcookie("ciacho", "", time()-3600);
	unset($_COOKIE['ciacho']);
	echo '
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Ankieta - rzeźba</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="container">
  <h2>Coś poszło nie tak</h2>
  <form action="/rzezba">
  Błędnie wpisałeś kod.<br>Twój numer telefonu został zablokowany w systemie. Jeśli to była pomyłka prosimy o przesłanie numeru telefonu na adres konsultuj@um.pulawy.pl   
    <button type="submit">Wróć do regulaminu</button>
  </form>

  
</div>
  <script src="https://cdn.jsdelivr.net/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>

  

    <script  src="js/index.js"></script>




</body>

</html>	
	
	
	';
}

?>