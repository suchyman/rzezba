<?php
//require("jdnw31.php");

//echo "ciastko: " . $_COOKIE["ciacho"] . ".<br>";

$kodzik = rand(100000, 999999);
$ciasteczko = $_COOKIE["ciacho"];

$wyn1= $_GET['pradio1'];
$wyn2= $_GET['lradio2'];
$tel = $_GET['tel'];

$ip = $_SERVER['REMOTE_ADDR'];
$servername = "localhost";
$username = "root";
$password = "xxx";
$dbname = "ankieta";

$today = date("Y-m-d H:i:s");





// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "SELECT telefon FROM odp WHERE telefon = $tel";
$result = $conn->query($sql);

//$sql2 = "SELECT kod FROM odp WHERE kod = $kodzik";
//$result2 = $conn->query($sql2);

if ($result->num_rows > 0)  {
    // output data of each row
setcookie("ciacho", "", time()-3600);
unset($_COOKIE['ciacho']);
//echo 'ilość wystąpień kodów: ' . $result2;
    echo' 
    
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Ankieta - rzeźba</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="container">
  <form action="/rzezba">
  Twój numer telefonu został już wkorzystany   
    <button type="submit">Wróć do początku</button>
  </form>

  
</div>
  <script src="https://cdn.jsdelivr.net/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>

  

    <script  src="js/index.js"></script>




</body>

</html>	    
    
    
    
    
   ' ;
    }
 else {
    



// zapisujemy w bazie pierwsze wyniki bez wpisywania kod2
$sql = "INSERT INTO odp (id, wyn1, wyn2, telefon, kod, ip, data, ok, ciastko, wkod)
VALUES ('', '$wyn1', '$wyn2', '$tel', '$kodzik', '$ip', '$today', '0', '$ciasteczko', '0')";

if (mysqli_query($conn, $sql)) {
   // echo "New record created successfully";
} else {
    //echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);



if (isset($_COOKIE["ciacho"])) {
	
$projekt = $_GET['pradio1'] . "<br>";
$lokalizacja = $_GET['lradio2'] . "<br>";
$tel = $_GET['tel'];
//	echo '<br>Kod autoryzacyjny wysłany na telefon: ' . $kodzik;
	
/*
Staram się wyjąć liczbę wpisanych już takich samych kodów..
$ip = $_SERVER['REMOTE_ADDR'];
$servername = "localhost";
$username = "root";
$password = "BimeshaiCh4ool2e";
$dbname = "ankieta";

$today = date("Y-m-d H:i:s");

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

	$sql2 = "SELECT COUNT(kod) FROM odp WHERE kod = $kodzik";
   $result2 = $conn->query($sql2);
   //$result2 = "12312312312312333333333333";
   echo '<br>' . $result2[0];
*/



function sms_send($params, $token, $backup = false)
{

    static $content;

    if ($backup == true) {
        $url = 'https://api2.smsapi.pl/sms.do';
    } else {
        $url = 'https://api.smsapi.pl/sms.do';
    }

    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, $url);
    curl_setopt($c, CURLOPT_POST, true);
    curl_setopt($c, CURLOPT_POSTFIELDS, $params);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($c, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer $token"
    ));

    $content = curl_exec($c);
    $http_status = curl_getinfo($c, CURLINFO_HTTP_CODE);

    if ($http_status != 200 && $backup == false) {
        $backup = true;
        sms_send($params, $token, $backup);
    }

    curl_close($c);
    return $content;
}

$token = "xxxx"; //https://ssl.smsapi.com/webapp#/oauth/manage

$params = array(
    'to' => $tel, //numery odbiorców rozdzielone przecinkami
    'from' => 'Info', //pole nadawcy
    'message' => "Twoje haslo do autoryzacji ankiety to: " . $kodzik //treść wiadomości
);

sms_send($params, $token); 

	
echo '

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Ankieta - rzeźba</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="container">
  <h2>Ankieta dotycząca projektu i lokalizacji rzeźby</h2>
  <form action="thx.php" name="ankieta">

    <label for="kod">Kod został wysłany na podany przez Ciebie numer telefonu - ' . $tel . '. Przepisz kod autoryzacyjny z SMS w pole poniżej:</label>
    <input type="text" name="kod" id="kod" placeholder="6-cio cyfrowy kod z SMS">
   
    <button type="submit">Oddaj głos</button>
  </form>

  
</div>
  <script src="https://cdn.jsdelivr.net/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>

  

    <script  src="js/index.js"></script>




</body>

</html>';}

else {
	echo '
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Ankieta - rzeźba</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="container">
  <form action="/rzezba">
  Nie zaakceptowałeś regulaminu!!!   
    <button type="submit">Wróć do regulaminu</button>
  </form>

  
</div>
  <script src="https://cdn.jsdelivr.net/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>

  

    <script  src="js/index.js"></script>




</body>

</html>	
	
	
	';
}}

?>