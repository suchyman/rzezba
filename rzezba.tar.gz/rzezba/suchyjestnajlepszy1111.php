<?php
// Create connection

$servername = "localhost";
$username = "root";
$password = "xxx";
$dbname = "ankieta";



$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    }

//dotad jest ok

$sql = "SELECT id, wyn1, wyn2, telefon, kod, ip, data, ok, ciastko, wkod FROM odp";
$result = $conn->query($sql);
$rowcount=mysqli_num_rows($result);



$sql2 = "SELECT DISTINCT wkod FROM odp WHERE ok = 1 AND kod=wkod ORDER BY data";
$result2 = $conn->query($sql2);
$iloscuniq=mysqli_num_rows($result2);




echo '<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Ankieta - rzeźba</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="container">
  <h2>Wyniki ankiety</h2>
  
  ';
echo 'Ilość głosów wszystkich: ' . $rowcount . '<br>';
echo 'Ilość unikalnych głosów: ' . $iloscuniq . ' - czyli tych ważnych<br>';
  
  
  
    echo '
  <form action="">
<table border="1">
<tr><td>ID</td><td>Projekt</td><td>Lokalizacja</td><td>Telefon</td><td>kod</td><td>IP</td><td>data</td><td>Potw.</td><td>ciacho</td><td>potwierdzone ciacho</td></tr>

  ';
  
$sql = "SELECT id, wyn1, wyn2, telefon, kod, ip, data, ok, ciastko, wkod FROM odp";
$result = $conn->query($sql);
$rowcount=mysqli_num_rows($result);



if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row['id'] . "</td><td>" . $row['wyn1'] . "</td><td>" . $row['wyn2'] . "</td><td>" . substr($row['telefon'],0,-3). "***" . "</td><td>" . $row['kod'] . "</td><td>" . substr($row['ip'],0,-3) . "***" . "</td><td>" . $row['data'] . "</td><td>" . $row['ok'] . "</td><td>" . $row['ciastko'] . "</td><td>" . $row['wkod'] . "</td></tr>";
    }
} else {
    echo "0 results";
}
$conn->close();





    echo' 
    
</table>  
  
    <button type="submit">Odśwież</button>
  </form>

  
</div>
  <script src="https://cdn.jsdelivr.net/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>

  

    <script  src="js/index.js"></script>




</body>

</html>	    
    
    
    
    
   ' ;
    
    
    ?>