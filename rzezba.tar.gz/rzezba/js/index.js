// Wait for the DOM to be ready
$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
  $("form[name='ankieta']").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      pradio1: "required",
      lradio2: "required",
      //kod:"required",
      
      tel: {
      required: true,
      minlength: 9,
      maxlength: 9,
      number: true
      }
      //kod: {
      //minlength:5;
      //maxlength:5;
      //requied:true;
      //number:true
      //}
    },
    errorElement : 'div',
    errorLabelContainer: '.errorTxt',
    // Specify validation error messages
    messages: {
      pradio1: "Musisz wybrać któryś projekt",
      lradio2: "Musisz wybrać którąś lokalizację",
      tel: {
        required: "Proszę o wprowadzenie telefonu",
        minlength: "Numer telefonu musi się składać z 9 cyfr, bez spacji - np. 123123123"
      },
      tel: "Proszę podać poprawny numer telefonu, np. 123123123"
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }
  });
});