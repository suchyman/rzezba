<?php

$random = rand(3, 3213123);

$ciacho = $_COOKIE["ciacho"];
setcookie("ciacho",$random,time()+3600);

?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Ankieta dotycząca rzeźby</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="container">
  <h2>Zapraszamy do zapoznania się z informacjami o RODO i ciasteczkach</h2>
  <form action="index2.php" name="ankieta">

    Szanowni Państwo, <br><br>
Od dnia 25 maja 2018 roku obowiązuje Rozporządzenie Parlamentu Europejskiego i Rady (UE) 2016/679 z dnia 27 kwietnia 2016r. (RODO) dlatego realizując obowiązek informacyjny, określony w art. 13 rozporządzenia informuję, iż:<br>
Administratorem Państwa danych osobowych jest Prezydent Miasta Puławy, Urząd Miasta Puławy, 24-100 Puławy, ul. Lubelska 5.<br>
Możesz się z nami skontaktować za pośrednictwem Inspektora Ochrony Danych Osobowych pod adresem: Urząd Miasta Puławy, ul. Lubelska 5, 24-100 Puławy, mailowo: iod@um.pulawy.pl oraz telefonicznie: 81 458-61-07.<br><br>
Ponadto informujemy, że podmiotem przetwarzającym i odbiorcą Państwa danych jest Centrum Usług Wspólnych w Puławach, 24-100 Puławy, ul. Piłsudskiego 83. Ponadto odbiorcami danych mogą być operatorzy usług informatycznych i hostingowych, w zakresie danych niezbędnych do zrealizowania usług świadczonych drogą elektroniczną.<br>
Przetwarzamy dane osobowe, które są zbierane podczas korzystania przez Państwo z tego portalu. Chodzi o takie dane jak: <b>numer telefonu, adresy IP oraz informacje zapisywane w plikach cookies.</b><br>
Głównym celem przetwarzania przez nas Państwa danych jest zapewnienie Państwu pełnej funkcjonalności działania portalu www.wibo.um.pulawy.pl służącego do składania wniosków do Budżetu Obywatelskiego.<br><br>
Podstawą przetwarzania danych jest Państwa dobrowolna i świadoma zgoda (art. 6 ust. 1 lit. a RODO). Podanie danych osobowych jest dobrowolne jednakże ich podanie może okazać się niezbędne dla korzystania z określonych funkcjonalności serwisu.<br><br>
Państwa dane osobowe będą przechowywane przez okres składania wniosków do Budżetu Obywatelskiego a następnie przez okres 2 lat od dnia złożenia wniosku.
W związku z przetwarzaniem danych macie Państwo prawo do: żądania od administratora dostępu do danych osobowych, prawo do ich sprostowania, usunięcia lub ograniczenia przetwarzania, prawo do wniesienia sprzeciwu wobec przetwarzania, prawo do przenoszenia danych, prawo do cofnięcia zgody w dowolnym momencie. W celu realizacji uprawnień, osoba której dane dotyczą, może wysłać stosowną wiadomość e-mail na adres administratora danych iod@um.pulawy.pl<br>
Organem nadzorczym nad administratorem danych osobowych jest Prezes Urzędu Ochrony Danych Osobowych, do którego przysługuje prawo wniesienia skargi za każdym razem, gdy w Państwa ocenie dane będą przetwarzane w sposób nieprawidłowy.<br><br>
Państwa dane nie będą poddane zautomatyzowanemu podejmowaniu decyzji. <br>
Administrator nie będzie przetwarzać danych osobowych w celu innym niż cel, w którym dane osobowe zostały zebrane.<br>
Państwa dane nie będą przekazane odbiorcy w państwie trzecim lub organizacji międzynarodowej.<br>

<br>INFORMACJA DOTYCZĄCA PLIKÓW COOKIES</b><br>
Informujemy, iż w celu optymalizacji treści dostępnych w naszym serwisie, dostosowania ich do Państwa indywidualnych potrzeb korzystamy z informacji zapisanych za pomocą plików cookies na urządzeniach końcowych użytkowników. Pliki cookies użytkownik może kontrolować za pomocą ustawień swojej przeglądarki internetowej. Dalsze korzystanie z naszego serwisu internetowego, bez zmiany ustawień przeglądarki internetowej oznacza, iż użytkownik akceptuje stosowanie plików cookies.</br></br>

<b><font color="#cc0000">UWAGA: Na jeden numer telefonu można wysłać tylko 1 SMS (1 telefon = 1 głos!!!)</font></b>

    <button type="submit">Rozumiem powyższą informację i chcę przejść do ankiety</button>
  </form>

  
</div>
  <script src='https://cdn.jsdelivr.net/jquery/1.12.4/jquery.min.js'></script>
<script src='https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>
